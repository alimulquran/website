<html lang="en">

<head>
  <meta charset="UTF-8">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css">

  <style>



    main {
      position: relative;
      width: calc(min(90rem, 90%));
      margin: 0 auto;
      min-height: 60vh;
      column-gap: 3rem;
      padding-block: min(20vh, 3rem);

    }

    .bg {
      position: fixed;
      top: -4rem;
      left: -12rem;
      z-index: -1;
      opacity: 0;
    }

    .bg2 {
      position: fixed;
      bottom: -2rem;
      right: -3rem;
      z-index: -1;
      width: 9.375rem;
      opacity: 0;
    }

    main>div span {
      text-transform: uppercase;
      letter-spacing: 1.5px;
      font-size: 1.2rem;
      color: #717171;
    }

    main>div h1 {
      text-transform: capitalize;
      letter-spacing: 0.8px;
      font-family: "Roboto", sans-serif;
      font-weight: 900;
      font-size: clamp(3.4375rem, 3.25rem + 0.75vw, 4rem);
      background-color: #ac2905;
      background-image: linear-gradient(45deg, #ac2905, #000000);
      background-size: 100%;
      background-repeat: repeat;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      -moz-background-clip: text;
      -moz-text-fill-color: transparent;
    }

    main>div hr {
      display: block;
      background: #ac2905;
      height: 0.25rem;
      width: 6.25rem;
      border: none;
      margin: 1.125rem 0 1.875rem 0;
    }

    main>div p {
      line-height: 1.6;
    }

    main a {
      display: inline-block;
      text-decoration: none;
      text-transform: uppercase;
      color: #717171;
      font-weight: 500;
      background: #fff;
      border-radius: 3.125rem;
      transition: 0.3s ease-in-out;
    }

    main>div>a {
      border: 2px solid #c2c2c2;
      margin-top: 2.188rem;
      padding: 0.625rem 1.875rem;
    }

    main>div>a:hover {
      border: 0.125rem solid #ac2905;
      color: #ac2905;
    }

    .swiper {
      width: 100%;
      padding-top: 3.125rem;
    }

    .swiper-pagination-bullet,
    .swiper-pagination-bullet-active {
      background: #fff;
    }

    .swiper-pagination {
      bottom: 1.25rem !important;
    }

    .swiper-slide {
      width: 18.75rem;
      height: 28.125rem;
      display: flex;
      flex-direction: column;
      justify-content: end;
      align-items: self-start;
    }

    .swiper-slide h2 {
      color: #fff;
      font-family: "Roboto", sans-serif;
      font-weight: 400;
      font-size: 1.4rem;
      line-height: 1.4;
      margin-bottom: 0.625rem;
      padding: 0 0 0 1.563rem;
      text-transform: uppercase;
    }

    .swiper-slide p {
      color: #dadada;
      font-family: "Roboto", sans-serif;
      font-weight: 300;
      padding: 0 1.563rem;
      line-height: 1.6;
      font-size: 0.75rem;
      display: -webkit-box;
      -webkit-line-clamp: 4;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .swiper-slide a {
      margin: 1.25rem 1.563rem 3.438rem 1.563rem;
      padding: 0.438em 1.875rem;
      font-size: 0.9rem;
    }

    .swiper-slide a:hover {
      color: #ac2905;
    }

    .swiper-slide div {
      display: none;
      opacity: 0;
      padding-bottom: 0.625rem;
    }

    .swiper-slide-active div {
      display: block;
      opacity: 1;
    }

    .swiper-slide--one {
      background: linear-gradient(to top, #0f2027, #203a4300, #2c536400), url("https://alimulquran.com/img/slider-1.jpg") no-repeat 50% 50%/cover;
    }

    .swiper-slide--two {
      background: linear-gradient(to top, #0f2027, #203a4300, #2c536400), url("https://alimulquran.com/img/slider-3.jpg") no-repeat 50% 50%/cover;
    }

    .swiper-slide--three {
      background: linear-gradient(to top, #0f2027, #203a4300, #2c536400), url("https://alimulquran.com/img/slider-6.jpg") no-repeat 50% 50%/cover;
    }

    .swiper-slide--four {
      background: linear-gradient(to top, #0f2027, #203a4300, #2c536400), url("https://alimulquran.com/img/slider-4.jpg") no-repeat 50% 50%/cover;
    }

    .swiper-slide--five {
      background: linear-gradient(to top, #0f2027, #203a4300, #2c536400), url("https://alimulquran.com/img/slider-5.jpg") no-repeat 50% 50%/cover;
    }

    .swiper-3d .swiper-slide-shadow-left,
    .swiper-3d .swiper-slide-shadow-right {
      background-image: none;
    }

    @media screen and (min-width: 48rem) {
      main {
        display: flex;
        align-items: center;
      }

      .bg,
      .bg2 {
        opacity: 0.1;
      }
    }

    @media screen and (min-width: 93.75rem) {
      .swiper {
        width: 85%;
      }
    }
  </style>

  <script>
    window.console = window.console || function (t) { };
  </script>



</head>

<body translate="no" data-new-gr-c-s-check-loaded="14.1131.0" data-gr-ext-installed="">
  <main>

    <div class="col-5">
      <span>QURAN & ARABIC</span>
      <h1>TEACHERS</h1>
      <hr>
      <p style="
    font-size: 1.5rem;"> Meet experienced online Quran teachers with extensive knowledge and long experience in
        teaching Quran, Arabic, and Islamic studies to kids and adults via the internet.</p>
      <a href="#teacher-recitation">Listen to Our Teachers Recitation</a>
    </div>
    <div
      class=" col swiper swiper-coverflow swiper-3d swiper-initialized swiper-horizontal swiper-pointer-events swiper-watch-progress">
      <div class="swiper-wrapper" id="swiper-wrapper-f8dd8361076e5d138" aria-live="polite"
        style="cursor: grab; transition-duration: 0ms; transform: translate3d(-1686px, 0px, 0px);">
        
        <div class="swiper-slide swiper-slide--one swiper-slide-duplicate-next pb-4" data-swiper-slide-index="0" role="group"
          aria-label="1 / 5"
          style="width: 281px; transition-duration: 0ms; transform: translate3d(0px, 0px, -1200px) rotateX(0deg) rotateY(0deg) scale(1); z-index: -11;">
          <div>
            <h2>What is a Quran Teacher?</h2>
            <p>Quran Teacher is a Muslim person who kept on learning the Quran correctly and excelled in it until he/she aggregated sufficient knowledge to teach it to others.</p>
          </div>
          <div class="swiper-slide-shadow-left" style="opacity: 12; transition-duration: 0ms;"></div>
          <div class="swiper-slide-shadow-right" style="opacity: 0; transition-duration: 0ms;"></div>
        </div>
        <div class="swiper-slide swiper-slide--two pb-4" data-swiper-slide-index="1" role="group" aria-label="2 / 5"
          style="width: 281px; transition-duration: 0ms; transform: translate3d(0px, 0px, -900px) rotateX(0deg) rotateY(0deg) scale(1); z-index: -8;">
          <div>
            <h2>Quran Tutor </h2>
            <p>
            Also, Quran Tutor should have studied the Arabic language very well, in addition to basic Islamic Studies. This knowledge is required in order to be able to teach Quran to others properly.
            </p>
          </div>
          <div class="swiper-slide-shadow-left" style="opacity: 9; transition-duration: 0ms;"></div>
          <div class="swiper-slide-shadow-right" style="opacity: 0; transition-duration: 0ms;"></div>
        </div>

        <div class="swiper-slide swiper-slide--three pb-4" data-swiper-slide-index="2" role="group" aria-label="3 / 5"
          style="width: 281px; transition-duration: 0ms; transform: translate3d(0px, 0px, -600px) rotateX(0deg) rotateY(0deg) scale(1); z-index: -5;">

          <div>
            <h2>Online Quran Teacher </h2>
            <p>
            Online Quran teacher is the ideal solution for those who live in a place where there are no Quran teachers nearby. You can get Quran study and Arabic studies via the internet with the same quality as you in physical classes.
            </p>
                     </div>
          <div class="swiper-slide-shadow-left" style="opacity: 6; transition-duration: 0ms;"></div>
          <div class="swiper-slide-shadow-right" style="opacity: 0; transition-duration: 0ms;"></div>
        </div>

        <div class="swiper-slide swiper-slide--four swiper-slide-visible swiper-slide-prev pb-4" data-swiper-slide-index="3"
          role="group" aria-label="4 / 5"
          style="width: 281px; transition-duration: 0ms; transform: translate3d(0px, 0px, -300px) rotateX(0deg) rotateY(0deg) scale(1); z-index: -2;">

          <div>
            <h2>Quran Tutors Online</h2>
            <p>
            With the help of Quran tutors online, you can learn Quran memorization, Quran recitation, and much more Quran skills from the comfort of your home at times that suit your schedule. 
            </p>
           
          </div>
          <div class="swiper-slide-shadow-left" style="opacity: 3; transition-duration: 0ms;"></div>
          <div class="swiper-slide-shadow-right" style="opacity: 0; transition-duration: 0ms;"></div>
        </div>

        <div class="swiper-slide swiper-slide--five swiper-slide-visible swiper-slide-active pb-4"
          data-swiper-slide-index="4" role="group" aria-label="5 / 5"
          style="width: 287px;transition-duration: 0ms;transform: translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg) scale(1);z-index: 1;">

          <div>
            <h2>Can You Learn Quran Online?</h2>
            <p>
            You can learn Quran online fast & easy at Alim ul Quran Institute with the help of highly-qualified teacher Quran online.
            </p>
         
          </div>
          <div class="swiper-slide-shadow-left" style="opacity: 0; transition-duration: 0ms;"></div>
          <div class="swiper-slide-shadow-right" style="opacity: 0; transition-duration: 0ms;"></div>
        </div>
       
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal">
        <span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span
          class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span><span
          class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span
          class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 4"></span><span
          class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button"
          aria-label="Go to slide 5" aria-current="true"></span></div>
      <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
    </div>
    <img src="https://cdn.pixabay.com/photo/2021/11/04/19/39/jellyfish-6769173_960_720.png" alt="" class="bg">
    <img src="https://cdn.pixabay.com/photo/2012/04/13/13/57/scallop-32506_960_720.png" alt="" class="bg2">
  </main>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js"></script>
  <script id="rendered-js">
    /*
    inspiration
    https://dribbble.com/shots/4684682-Aquatic-Animals
    */

    var swiper = new Swiper(".swiper", {
      effect: "coverflow",
      grabCursor: true,
      centeredSlides: true,
      coverflowEffect: {
        rotate: 0,
        stretch: 0,
        depth: 100,
        modifier: 3,
        slideShadows: true
      },

      keyboard: {
        enabled: true
      },

      mousewheel: {
        thresholdDelta: 70
      },

      loop: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true
      },

      breakpoints: {
        640: {
          slidesPerView: 2
        },

        768: {
          slidesPerView: 1
        },

        1024: {
          slidesPerView: 2
        },

        1560: {
          slidesPerView: 3
        }
      }
    });
    //# sourceURL=pen.js
  </script>





</body><grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>

</html>